/**
 * state.js - 에디터 전역 상태 관리
 */
window.PicEditor = window.PicEditor || {};

window.PicEditor.state = {
  activeTab: 1,
  selectedElement: null,
  selectedElements: [], // 다중 선택 요소 배열
  activeLayer: 'all',   // 현재 작업 레이어 ('all', 'diagram', 'text', 'background')
  isDragging: false,
  startX: 0,
  startY: 0,
  isDrawMode: false,
  isDrawing: false,
  drawStart: { x: 0, y: 0 },
  tempShape: null,
  isDraggingArcCenter: false,
  isDraggingArcP1: false,
  isDraggingArcP2: false,
  isDraggingLineP1: false,
  isDraggingLineP2: false,
  isDraggingCircleCenter: false,
  isDraggingParabolaV: false,
  isDraggingParabolaP1: false,
  isDraggingParabolaP2: false,
  isDraggingTriangleP1: false,
  isDraggingTriangleP2: false,
  isDraggingTriangleP3: false,
  isDraggingRectCorner: false,
  rectCornerIndex: -1,
  rectAnchor: { x: 0, y: 0 },
  // 현재 캔버스에 로드된 도면 정보 추적
  currentDiagramName: '',
  currentDiagramSha: null,
  currentThumbSha: null
};
